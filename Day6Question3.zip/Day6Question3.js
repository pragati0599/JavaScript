const title = document.getElementById('title')
console.log(title);
console.log(title.innerText);
const name =  prompt("enter your name");
title.innerText += 'welcome to the letsupgrade ' +name;


const dmode=document.getElementById('dark');
 dmode.onclick = function changecolor(){
    setTimeout(()=>{
        document.body.style.backgroundColor = 'black';
        document.body.style.color = 'white';
        document.body.style.fontFamily = 'Helvetica';
    },3000);

 }

 const ctime = document.getElementById('time');

function clock()
{
    let date =new Date();
    let time = date.toLocaleTimeString();
    ctime.innerText = time;

}
setInterval(clock,1000)
