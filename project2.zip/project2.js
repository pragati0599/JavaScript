var Seconds;
var interval;
function reset()
{
      document.getElementById("inputArea").style.display="none";
}
    function count()
    {
        var timedisplay=document.getElementById("time");
        var min=Math.floor(Seconds/60);
        var sec=Seconds-(min*60);
        if (sec < 10) 
        {
           sec="0"+sec;
        }
            var message=min.toString()+":"+sec; 
            timedisplay.innerHTML=message; 
            if(Seconds===0)
            {
                alert("Done"); 
                clearInterval(interval); 
                reset();
            } 
                Seconds--; 
            }
                function starttimer()
                { 
                    var input=document.getElementById("minutes").value;
                     if (isNaN(input))
                     {
                          alert("Type a valid number please"); 
                          return; 
                     }
                         Seconds=input*60; 
                         interval=setInterval(count, 1000); 
                         document.getElementById("inputArea").style.display="none"; 
                        }
                         window.onload=function()
                         { 
                             var input=document.createElement("input"); 
                             input.setAttribute("type","text");
                              input.setAttribute("id","minutes"); 
                              var Button=document.createElement("input"); 
                              Button.setAttribute("type","button"); 
                              Button.setAttribute("value","Start Timer"); 
                              Button.onclick=function()
                              {
                                   starttimer(); 
                                } 
                                document.getElementById("inputArea").appendChild(input); 
                                document.getElementById("inputArea").appendChild(Button); 
                            }
