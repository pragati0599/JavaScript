// let num=prompt("enter a positive number:");

let arr=[2,3,4,5,6,7,13]
console.log(arr);

let odd=arr.filter(el=>el%2!=0);
console.log(odd);

//now we have to generate the cubes of the filter array

let oddcubes=arr.filter(el=>el%2!=0).map(el=>el**3);
console.log(oddcubes); 