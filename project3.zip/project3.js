var quotes=['o one thing every day that scares you.― Eleanor Roosevelt',
    'It’s no use going back to yesterday, because I was a different person then.― Lewis Carroll',
    'Smart people learn from everything and everyone, average people from their experiences, stupid people already have all the answers. – Socrates',
    'Do what you feel in your heart to be right – for you’ll be criticized anyway.― Eleanor Roosevelt',
    'Happiness is not something ready made. It comes from your own actions. ― Dalai Lama XIV',
    'Whatever you are, be a good one. ― Abraham Lincoln',
    'Impossible is just an opinion. – Paulo Coelho',
    'Your passion is waiting for your courage to catch up. – Isabelle Lafleche',
    'Magic is believing in yourself. If you can make that happen, you can make anything happen. – Johann Wolfgang Von Goethe',
    'If something is important enough, even if the odds are stacked against you, you should still do it. – Elon Musk']

function newquote()
{
    var randomNumber = Math.floor(Math.random()* (quotes.length));
    document.getElementById('quote').innerHTML=quotes[randomNumber];
}