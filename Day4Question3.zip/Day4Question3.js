let shoppinglist = ['Maggie','Pasta','Biscuits','french fries']
        console.log(shoppinglist)

        //copying the elements of shoopinglist array to shoppingbascket

        //let shoppingbascket =[...shoppinglist]
        //console.log(shoppingbascket)

        // adding new products to shoppingbascket array

        let shoppingbascket =['Tomato ketchup',...shoppinglist,'amul butter','paneer']
        console.log(shoppingbascket)